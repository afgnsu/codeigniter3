<?php require_once VIEWPATH.'_layouts/header.php' ?>
<section class="container">
	<h1 class="text-info text-center"><?= $query->title ?></h1>
	<p class="well"><?= $query->content ?></p>
</section>
<?php require_once VIEWPATH.'_layouts/footer.php' ?>
